
USE SelfLearningSystems


CREATE TABLE Users (
    ID int IDENTITY(1,1) PRIMARY KEY,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255) NOT NULL,
	EmailId varchar(255) NOT NULL,
	Password varchar(255) NOT NULL
)

CREATE TABLE Category (
    Cat_Id int IDENTITY(1,1) PRIMARY KEY,
    Cat_Name varchar(255) NOT NULL,
)

CREATE TABLE Transcript (
    Tran_Id int IDENTITY(1,1) PRIMARY KEY,
    Descriptions varchar(255) NOT NULL,
)

CREATE TABLE Instructor (
    Inst_Id int IDENTITY(1,1) PRIMARY KEY,
    Inst_Name varchar(255) NOT NULL,
)

CREATE TABLE Chapter (
    Ch_Id int IDENTITY(1,1) PRIMARY KEY,
    Ch_Name varchar(255) NOT NULL,
	Video varchar(255) NOT NULL,
	Tran_Id int NOT NULL FOREIGN KEY REFERENCES Transcript(Tran_Id)  
)

CREATE TABLE Course (
    C_Id int IDENTITY(1,1) PRIMARY KEY,
    C_Name varchar(255) NOT NULL,
	C_Length varchar(255) NOT NULL,
	Cat_Id int NOT NULL FOREIGN KEY REFERENCES Category (Cat_Id), 
	Ch_Id int NOT NULL FOREIGN KEY REFERENCES Chapter(Ch_Id), 
	Inst_Id int NOT NULL FOREIGN KEY REFERENCES Instructor(Inst_Id) 
)

select * from Course;


