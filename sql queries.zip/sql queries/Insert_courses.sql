insert into Course values ('CSS', '15 Min', '1', '1', '1');
insert into Category values ('Frontend');
insert into Instructor values ('Logan');
insert into Chapter values ('Introduction', 'chapter1-video', '1');
insert into Transcript values ('Hello');

select * from Course;




insert into Course values ('Java', '35 Min', '1', '1', '1');
insert into Category values ('Frontend');
insert into Instructor values ('Caitlyn');
insert into Chapter values ('Introduction', 'chapter1-video', '1');
insert into Transcript values ('Hello');

select * from Course;



insert into Course values ('C++', '45 Min', '1', '1', '1');
insert into Category values ('Frontend');
insert into Instructor values ('Alice');
insert into Chapter values ('Introduction', 'chapter1-video', '1');
insert into Transcript values ('Hello');

select * from Course;






insert into Course values ('C#', '45 Min', '1', '1', '1');
insert into Category values ('Frontend');
insert into Instructor values ('John');
insert into Chapter values ('Introduction', 'chapter1-video', '1');
insert into Transcript values ('Hello');

select * from Course;




insert into Course values ('Python', '45 Min', '1', '1', '1');
insert into Category values ('Frontend');
insert into Instructor values ('Nancy');
insert into Chapter values ('Introduction', 'chapter1-video', '1');
insert into Transcript values ('Hello');

select * from Course;



insert into Course values ('Ruby', '45 Min', '1', '1', '1');
insert into Category values ('Frontend');
insert into Instructor values ('Daniel');
insert into Chapter values ('Introduction', 'chapter1-video', '1');
insert into Transcript values ('Hello');

select * from Course;