USE [SelfLearningSystems]


Create Proc spGetCourseName 'j'
@CourseName nvarchar(50)
as 
Begin
	select C_Name from Course
	where C_Name LIKE @CourseName + '%' 
End

Create Proc spGetAllCourses 'h'
@CourseName nvarchar(50) = NULL
as
Begin
	select * from Course
	where C_Name LIKE @CourseName + '%' or @CourseName IS NULL
End

insert into Course values ('Javascript', '30 Min', '1', '1', '1');
insert into Category values ('Frontend');
insert into Instructor values ('Anir');
insert into Chapter values ('Introduction', 'chapter1-video', '1');
insert into Transcript values ('Hello');

select * from Course;